---
name: design-system-barzily
description: Creates implementation-ready design-system guidance with tokens, component behavior, and accessibility standards. Use when creating or updating UI rules, component specifications, or design-system documentation for ברזילי, עזורי ושות׳ (baz-law.co.il).
---
<!-- BARZILY_DESIGN_SYSTEM_START -->
# ברזילי, עזורי ושות'
## Mission
Deliver implementation-ready design-system guidance for ברזילי, עזורי ושות' that can be applied consistently across content site interfaces.
## Brand
- Product/brand: ברזילי, עזורי ושות'
- URL: https://www.baz-law.co.il/
- Audience: readers and knowledge seekers
- Product surface: content site
- Language / direction: Hebrew primary, RTL layout (`dir="rtl"` on `<html>`)
## Style Foundations
- Visual style: structured, accessible, implementation-first
- Main font style: `font.family.primary=Heebo`, `font.family.stack=Heebo, Arial, sans-serif`, `font.size.base=16px`, `font.weight.base=400`, `font.lineHeight.base=24px`
- Typography scale: `font.size.xs=10.88px`, `font.size.sm=12px`, `font.size.md=12.32px`, `font.size.lg=12.48px`, `font.size.xl=12.8px`, `font.size.2xl=13px`, `font.size.3xl=13.12px`, `font.size.4xl=13.76px`
- Color palette: `color.text.primary=#0f2336`, `color.text.secondary=#f0f6ff`, `color.surface.muted=#ffffff`, `color.text.inverse=#4a6080`, `color.surface.base=#000000`, `color.surface.raised=#c5a44a`, `color.surface.strong=#f5f4f0`, `color.border.default=oklch(0.922 0 0)`, `color.border.muted=#1a3a5c`, `color.border.strong=oklch(0.922 0 0) rgb(197, 164, 74) oklch(0.922 0 0) oklch(0.922 0 0)`
- Spacing scale: `space.1=1px`, `space.2=4px`, `space.3=4.8px`, `space.4=7px`, `space.5=8px`, `space.6=8.8px`, `space.7=10.4px`, `space.8=12px`
- Radius/shadow/motion tokens: `radius.xs=4px`, `radius.sm=8px`, `radius.md=10px`, `radius.lg=12px`, `radius.xl=50px` | `shadow.1=rgba(15, 35, 54, 0.06) 0px 2px 16px 0px`, `shadow.2=rgba(201, 168, 76, 0.45) 0px 4px 18px 0px`, `shadow.3=rgba(158, 122, 42, 0.35) 0px 4px 20px 0px`, `shadow.4=rgba(201, 168, 76, 0.25) 0px 4px 14px 0px` | `motion.duration.instant=180ms`, `motion.duration.fast=200ms`, `motion.duration.normal=250ms`, `motion.duration.slow=300ms`, `motion.duration.slower=400ms`, `motion.duration.step6=800ms`, `motion.duration.step7=900ms`
## Accessibility
- Target: WCAG 2.2 AA
- Keyboard-first interactions required.
- Focus-visible rules required.
- Contrast constraints required.
## Writing Tone
concise, confident, implementation-focused
## Rules: Do
- Use semantic tokens, not raw hex values in component guidance.
- Every component must define required states: default, hover, focus-visible, active, disabled, loading, error.
- Responsive behavior and edge-case handling should be specified for every component family.
- Accessibility acceptance criteria must be testable in implementation.
- All layouts must respect RTL direction inherited from `dir="rtl"` on `<html>`.
## Rules: Don't
- Do not allow low-contrast text or hidden focus indicators.
- Do not introduce one-off spacing or typography exceptions.
- Do not use ambiguous labels or non-descriptive actions.
- Do not use `flex-direction: row-reverse` as a substitute for proper RTL layout.
- Do not use raw hex values in component specs — always reference semantic tokens.
## Guideline Authoring Workflow
1. Restate design intent in one sentence.
2. Define foundations and tokens.
3. Define component anatomy, variants, and interactions.
4. Add RTL-specific layout notes where relevant.
5. Add accessibility acceptance criteria.
6. Add anti-patterns and migration notes.
7. End with QA checklist.
## Required Output Structure
- Context and goals
- Design tokens and foundations
- Component-level rules (anatomy, variants, states, responsive behavior)
- RTL layout notes
- Accessibility requirements and testable acceptance criteria
- Content and tone standards with examples
- Anti-patterns and prohibited implementations
- QA checklist
## Component Rule Expectations
- Include keyboard, pointer, and touch behavior.
- Include spacing and typography token requirements.
- Include long-content, overflow, and empty-state handling.
## Quality Gates
- Every non-negotiable rule must use "must".
- Every recommendation should use "should".
- Every accessibility rule must be testable in implementation.
- Prefer system consistency over local visual exceptions.
- RTL layout must be verified on Chrome and Safari (mobile and desktop).

## ⚠️ Typography Scale Note
The extracted `font.size.*` tokens (xs–4xl range: 10.88px–13.76px) reflect computed values from the current CSS and are abnormally compressed for a marketing site. When authoring hero headings, section titles, or display text, override with intent-driven sizes:
- Hero headline: `clamp(32px, 5vw, 56px)`
- Section heading (h2): `clamp(24px, 3.5vw, 36px)`
- Subheading (h3): `clamp(18px, 2.5vw, 24px)`
- Body: `16px` (matches `font.size.base`)
These intent values take precedence over the extracted scale for display contexts.
<!-- BARZILY_DESIGN_SYSTEM_END -->

## Motion & Animation Philosophy
**Inspiration source:** gcblaws.com — calm authority, not decoration.
**Principle:** motion should feel inevitable, not surprising. Every animation must serve the content, not distract from it.

### Animation Vocabulary (GCB-inspired, not GCB-copied)

#### 1. Scroll Entry — `reveal-on-scroll`
Elements entering the viewport get a unified motion: `opacity 0→1` + `translateY(24px→0)`.
- Duration: `motion.duration.step6` (800ms), `ease-out`
- Stagger between siblings: 120ms delay per item
- Implementation: `IntersectionObserver`, `threshold: 0.15`
- Must respect `prefers-reduced-motion` — fallback: instant visibility, no transform

```css
.reveal {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity var(--motion-step6) ease-out,
              transform var(--motion-step6) ease-out;
}
.reveal.is-visible { opacity: 1; transform: translateY(0); }
@media (prefers-reduced-motion: reduce) {
  .reveal { opacity: 1; transform: none; transition: none; }
}
```

#### 2. Hero Section — `hero-sequence`
Static image with dark navy overlay (`color.surface.base` at 60% opacity). No autoplay video.
- Headline: `opacity 0→1` + `translateY(32px→0)`, delay 200ms, `motion.duration.step7` (900ms)
- Subheadline: same pattern, delay 400ms
- CTA button: same, delay 600ms
- **Why no video:** better performance, accessibility, and GitHub Pages compatibility

#### 3. Card Hover — `card-lift`
- `translateY(-4px)` + shadow `shadow.1` → `shadow.2` (gold glow)
- Duration: `motion.duration.normal` (250ms), `ease-in-out`
- Gold border appears on `border-inline-end` only (RTL-correct, no `right:` hardcoding)

```css
.card {
  transition: transform var(--motion-normal) ease-in-out,
              box-shadow var(--motion-normal) ease-in-out,
              border-color var(--motion-normal) ease-in-out;
}
.card:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-2);
  border-inline-end-color: var(--color-surface-raised);
}
```

#### 4. Practice Area Numbers — `counter-decoration`
Large ordinal numbers (01, 02, 03...) as decorative background text.
- Color: `color.surface.raised` (gold), size: `clamp(48px, 8vw, 80px)`, `opacity: 0.12`
- Must be `aria-hidden="true"` and `user-select: none`
- On card hover: opacity increases to `0.22`, `motion.duration.fast` (200ms)

#### 5. Navigation Underline — `nav-underline`
Active/hover links: gold underline grows via `::after` pseudo-element.
- Grows from `width: 0` → `width: 100%`, direction follows RTL naturally
- Duration: `motion.duration.fast` (200ms), `ease-out`
- Never use `text-decoration` — use `::after` for full control

#### 6. CTA Button — `button-shimmer`
On hover: subtle gold shimmer sweep across button surface.
- Background gradient animation, `motion.duration.slower` (400ms)
- Never flash, pulse, or blink

### Animation Anti-Patterns
- ❌ Do not animate more than 3 properties simultaneously
- ❌ Do not use rotation, bounce, or elastic easing — this is a law firm
- ❌ Do not autoplay video backgrounds
- ❌ Do not trigger exit animations on scroll (only enter)
- ❌ Do not use JS animation libraries (GSAP etc.) — CSS + IntersectionObserver only

### Motion QA Checklist
- [ ] All reveal animations respect `prefers-reduced-motion`
- [ ] Hero sequence completes within 1200ms total
- [ ] Card hover causes no layout shift
- [ ] Gold border uses `border-inline-end`, not `border-right`
- [ ] Decorative numbers are `aria-hidden="true"`
- [ ] All transitions tested on mobile Safari (iOS)
