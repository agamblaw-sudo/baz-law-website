# ברזילי, עזורי ושות'

## Mission
Create implementation-ready, token-driven UI guidance for ברזילי, עזורי ושות' that is optimized for consistency, accessibility, and fast delivery across content site.

---

## Brand

- **Product / brand:** ברזילי, עזורי ושות'
- **URL:** https://www.baz-law.co.il/
- **Audience:** readers and knowledge seekers
- **Product surface:** content site
- **Language / direction:** Hebrew primary, RTL layout (`dir="rtl"` on `<html>`)

---

## Style Foundations

- **Visual style:** structured, tokenized, content-first
- **Main font:** `font.family.primary=Heebo`, `font.family.stack=Heebo, Arial, sans-serif`, `font.size.base=16px`, `font.weight.base=400`, `font.lineHeight.base=24px`

### Typography Scale

| Token | Value |
|---|---|
| `font.size.xs` | `10.88px` |
| `font.size.sm` | `12px` |
| `font.size.md` | `12.32px` |
| `font.size.lg` | `12.48px` |
| `font.size.xl` | `12.8px` |
| `font.size.2xl` | `13px` |
| `font.size.3xl` | `13.12px` |
| `font.size.4xl` | `13.76px` |

> ⚠️ **Intent Override for Display Text**
> הטוקנים שחולצו מ-CSS משקפים ערכים מחושבים — דחוסים מדי לכותרות ו-hero text.
> לשימוש בכותרות ותצוגה השתמש בערכים האלה:
> - Hero headline: `clamp(32px, 5vw, 56px)`
> - Section heading (h2): `clamp(24px, 3.5vw, 36px)`
> - Subheading (h3): `clamp(18px, 2.5vw, 24px)`
> - Body: `16px` (= `font.size.base`)

---

### Color Palette

| Token | Value | Usage |
|---|---|---|
| `color.text.primary` | `#0f2336` | טקסט ראשי — navy כהה |
| `color.text.secondary` | `#f0f6ff` | טקסט בהיר על רקעים כהים |
| `color.text.inverse` | `#4a6080` | טקסט תומך / muted על רקע בהיר |
| `color.surface.base` | `#000000` | רקע שחור מלא — overlays, hero |
| `color.surface.muted` | `#ffffff` | לבן — רקע דף ברירת מחדל |
| `color.surface.raised` | `#c5a44a` | זהב — accent surface, badges, highlights |
| `color.surface.strong` | `#f5f4f0` | אוף-וויט — סקשנים מתחלפים |
| `color.border.default` | `oklch(0.922 0 0)` | מפרידים ניטרליים, גבולות קארד |
| `color.border.muted` | `#1a3a5c` | Navy — גבולות emphasis על רקע כהה |
| `color.border.strong` | Gold+neutral composite | גבולות active/focus, practice area cards |

> **קיצורי דרך לתיעוד קומפוננטים:**
> - Navy (brand primary): `color.text.primary` = `#0f2336`
> - Gold (accent): `color.surface.raised` = `#c5a44a`
> - White (background): `color.surface.muted` = `#ffffff`

---

### Spacing Scale

| Token | Value |
|---|---|
| `space.1` | `1px` |
| `space.2` | `4px` |
| `space.3` | `4.8px` |
| `space.4` | `7px` |
| `space.5` | `8px` |
| `space.6` | `8.8px` |
| `space.7` | `10.4px` |
| `space.8` | `12px` |

> ⚠️ **Layout Override**
> הסקייל הנוכחי (1px–12px) מתאים למיקרו-ספייסינג.
> ללייאוט ברמת סקשן:
> - Component padding: `16px / 24px`
> - Section vertical rhythm: `48px / 96px`
> - Content max-width: `1200px`

---

### Radius / Shadow / Motion

**Border radius:**

| Token | Value | Usage |
|---|---|---|
| `radius.xs` | `4px` | תגיות, badges |
| `radius.sm` | `8px` | inputs, כפתורים קטנים |
| `radius.md` | `10px` | כרטיסים, מודאלים |
| `radius.lg` | `12px` | פאנלים גדולים |
| `radius.xl` | `50px` | Pills, כפתורים עגולים |

**Shadow:**

| Token | Value | Usage |
|---|---|---|
| `shadow.1` | `rgba(15,35,54,0.06) 0px 2px 16px 0px` | Card default (navy tint) |
| `shadow.2` | `rgba(201,168,76,0.45) 0px 4px 18px 0px` | Gold glow — hover state |
| `shadow.3` | `rgba(158,122,42,0.35) 0px 4px 20px 0px` | Gold glow — pressed/focus |
| `shadow.4` | `rgba(201,168,76,0.25) 0px 4px 14px 0px` | Gold glow — subtle accent |

**Motion:**

| Token | Value | Usage |
|---|---|---|
| `motion.duration.instant` | `180ms` | מיקרו-אינטראקציות |
| `motion.duration.fast` | `200ms` | Hover color/border |
| `motion.duration.normal` | `250ms` | Card hover, shadow |
| `motion.duration.slow` | `300ms` | Panel open/close |
| `motion.duration.slower` | `400ms` | Drawer, accordion |
| `motion.duration.step6` | `800ms` | Page entry animations |
| `motion.duration.step7` | `900ms` | Hero sequence animations |

---

## Accessibility

- **Target:** WCAG 2.2 AA
- Keyboard-first interactions required on all interactive elements.
- `focus-visible` outline required: `2px solid color.surface.raised` (gold), `outline-offset: 2px`.
- Minimum contrast: 4.5:1 for normal text, 3:1 for large text.
- All images must have descriptive `alt` attributes in Hebrew.
- All form inputs must have explicit `<label>` elements (not placeholder-only).
- Skip-to-main link must be the first focusable element on every page.
- Navigation landmark roles must be explicit: `<nav>`, `<main>`, `<footer>`.

---

## Writing Tone

Concise, confident, implementation-focused.
Hebrew primary. CTAs must be action-oriented ("צרו קשר", "קבלו ייעוץ") — never generic ("לחצו כאן").

---

## Rules: Do

- Use semantic tokens, not raw hex values, in component guidance.
- Every component must define states: default, hover, focus-visible, active, disabled, loading, error.
- Component behavior should specify responsive and edge-case handling.
- Interactive components must document keyboard, pointer, and touch behavior.
- Accessibility acceptance criteria must be testable in implementation.
- All layouts must respect RTL direction from `dir="rtl"` on `<html>`.

---

## Rules: Don't

- Do not allow low-contrast text or hidden focus indicators.
- Do not introduce one-off spacing or typography exceptions.
- Do not use ambiguous labels or non-descriptive actions.
- Do not ship component guidance without explicit state rules.
- Do not use `flex-direction: row-reverse` as a substitute for RTL layout.
- Do not use raw hex values in component specs — always reference semantic tokens.
- Do not use gold (`color.surface.raised`) for body text — accent use only.
- Do not use placeholder text as a substitute for `<label>` elements.

---

## Guideline Authoring Workflow

1. Restate design intent in one sentence.
2. Define foundations and semantic tokens.
3. Define component anatomy, variants, interactions, and state behavior.
4. Add accessibility acceptance criteria with pass/fail checks.
5. Add anti-patterns, migration notes, and edge-case handling.
6. End with a QA checklist.

---

## Required Output Structure

- Context and goals.
- Design tokens and foundations.
- Component-level rules (anatomy, variants, states, responsive behavior).
- RTL layout notes.
- Accessibility requirements and testable acceptance criteria.
- Content and tone standards with Hebrew copy examples.
- Anti-patterns and prohibited implementations.
- QA checklist.

---

## Component Rule Expectations

- Include keyboard, pointer, and touch behavior.
- Include spacing and typography token requirements.
- Include long-content, overflow, and empty-state handling.
- **Known page component density:** links (57), cards (27), buttons (20), inputs (8), lists (5), navigation (1).
- RTL verification required on Chrome and Safari (mobile and desktop).

> ⚠️ Extraction diagnostics: Audience and product surface inference confidence is low — verify generated brand context before shipping.

---

## Quality Gates

- Every non-negotiable rule must use "must".
- Every recommendation should use "should".
- Every accessibility rule must be testable in implementation.
- Teams should prefer system consistency over local visual exceptions.
- Hebrew text rendering must be verified with `Heebo` loaded via Google Fonts.
- RTL layout must be verified before any component is considered complete.

---

## Motion & Animation Philosophy

**Inspiration source:** gcblaws.com — calm authority, not decoration.
**Principle:** Motion must feel inevitable, not surprising. Every animation serves the content.

---

### Animation Vocabulary (GCB-inspired, Barzily-adapted)

#### 1. Scroll Entry — `reveal-on-scroll`
Elements entering the viewport: `opacity 0→1` + `translateY(24px→0)`

| Property | Value |
|---|---|
| Duration | `motion.duration.step6` = 800ms |
| Easing | `ease-out` |
| Sibling stagger | 120ms per item |
| Trigger | `IntersectionObserver`, threshold 0.15 |
| Reduced motion | Instant visibility, no transform |

```css
.reveal {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity var(--motion-step6) ease-out,
              transform var(--motion-step6) ease-out;
}
.reveal.is-visible { opacity: 1; transform: translateY(0); }
@media (prefers-reduced-motion: reduce) {
  .reveal { opacity: 1; transform: none; transition: none; }
}
```

#### 2. Hero Section — `hero-sequence`
Static image + navy overlay (60% opacity). Headline, subheadline, and CTA button each enter sequentially.

| Element | Delay | Duration |
|---|---|---|
| Headline (h1) | 200ms | `motion.duration.step7` (900ms) |
| Subheadline | 400ms | `motion.duration.step7` (900ms) |
| CTA button | 600ms | `motion.duration.step7` (900ms) |

Motion: `opacity 0→1` + `translateY(32px→0)` for each.
**No video background** — GitHub Pages performance and WCAG 2.2 compliance.

#### 3. Card Hover — `card-lift`

| Property | Default | Hover |
|---|---|---|
| Transform | none | `translateY(-4px)` |
| Shadow | `shadow.1` | `shadow.2` (gold glow) |
| Border inline-end | `color.border.default` | `color.surface.raised` |
| Duration | — | `motion.duration.normal` (250ms) |

```css
.card {
  transition: transform var(--motion-normal) ease-in-out,
              box-shadow var(--motion-normal) ease-in-out,
              border-color var(--motion-normal) ease-in-out;
}
.card:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-2);
  border-inline-end-color: var(--color-surface-raised);
}
```

#### 4. Practice Area Numbers — `counter-decoration`
Decorative ordinals (01, 02...) behind card titles — GCB-inspired visual rhythm, adapted to baz-law palette.

- Size: `clamp(48px, 8vw, 80px)`
- Color: `color.surface.raised` (gold)
- Opacity: `0.12` default → `0.22` on hover (`motion.duration.fast`)
- Must: `aria-hidden="true"`, `user-select: none`, `pointer-events: none`

#### 5. Navigation Underline — `nav-underline`
Gold underline via `::after`, grows on hover/active.

```css
.nav-link::after {
  content: '';
  display: block;
  height: 2px;
  background: var(--color-surface-raised);
  width: 0;
  transition: width var(--motion-fast) ease-out;
}
.nav-link:hover::after,
.nav-link[aria-current="page"]::after {
  width: 100%;
}
```

RTL direction handled automatically since `::after` follows inline flow.

#### 6. CTA Button — `button-shimmer`
Subtle gold shimmer sweep on hover.
- Duration: `motion.duration.slower` (400ms)
- Never flash, pulse, or blink

---

### Animation Anti-Patterns

| ❌ Prohibited | ✅ Instead |
|---|---|
| Autoplay video background | Static image + hero-sequence reveal |
| Bounce / elastic easing | `ease-out` or `ease-in-out` only |
| Rotation on content elements | Static icons, no spin |
| Animating more than 3 properties at once | Limit to: opacity, transform, shadow |
| Exit animations on scroll | Entry only (no reverse on scroll-up) |
| JS animation libraries (GSAP, Framer Motion) | CSS transitions + IntersectionObserver |
| `border-right` in RTL components | `border-inline-end` always |

---

### Motion QA Checklist

- [ ] All scroll-reveal animations respect `prefers-reduced-motion`
- [ ] Hero sequence completes within 1200ms total
- [ ] Card hover causes no layout shift (no width/height change)
- [ ] Gold border uses `border-inline-end`, not `border-right`
- [ ] Decorative ordinals are `aria-hidden="true"`
- [ ] No `pointer-events` blocked during transitions
- [ ] Tested on mobile Safari iOS — transforms and transitions verified
- [ ] Tested with `prefers-reduced-motion: reduce` in OS settings
